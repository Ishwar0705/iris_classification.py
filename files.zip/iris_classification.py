"""
╔══════════════════════════════════════════════════════════════════╗
║        IRIS FLOWER CLASSIFICATION — CodeAlpha Internship        ║
║               Mote Ishwar Sunil | Ishwar's Tech                 ║
╚══════════════════════════════════════════════════════════════════╝

Task 1: Iris Flower Classification
- Dataset: Iris (built-in from Scikit-learn)
- Models: Logistic Regression, KNN, Random Forest, SVM
- Evaluation: Accuracy, Confusion Matrix, Classification Report
"""

# ── 1. IMPORTS ──────────────────────────────────────────────────
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import seaborn as sns
from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.neighbors import KNeighborsClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.svm import SVC
from sklearn.metrics import (accuracy_score, classification_report,
                             confusion_matrix, ConfusionMatrixDisplay)
import warnings
warnings.filterwarnings('ignore')

print("=" * 65)
print("   IRIS FLOWER CLASSIFICATION — CodeAlpha Data Science Task")
print("   Author: Mote Ishwar Sunil | Ishwar's Tech")
print("=" * 65)

# ── 2. LOAD DATASET ─────────────────────────────────────────────
iris = load_iris()
df = pd.DataFrame(data=iris.data, columns=iris.feature_names)
df['species'] = pd.Categorical.from_codes(iris.target, iris.target_names)
df['target'] = iris.target

print("\n📦 Dataset Loaded Successfully!")
print(f"   Shape        : {df.shape}")
print(f"   Features     : {list(iris.feature_names)}")
print(f"   Classes      : {list(iris.target_names)}")
print(f"   Missing vals : {df.isnull().sum().sum()}")

# ── 3. EDA ───────────────────────────────────────────────────────
print("\n📊 Basic Statistics:")
print(df.describe().round(2).to_string())

print("\n🌸 Class Distribution:")
print(df['species'].value_counts().to_string())

# ── 4. VISUALIZATIONS ────────────────────────────────────────────
fig, axes = plt.subplots(2, 3, figsize=(16, 10))
fig.suptitle("Iris Flower Classification — Exploratory Data Analysis\n"
             "Mote Ishwar Sunil | Ishwar's Tech | CodeAlpha Internship",
             fontsize=14, fontweight='bold', color='#2c3e50')

colors = ['#e74c3c', '#3498db', '#2ecc71']
species_list = iris.target_names

# Plot 1: Pairplot-style scatter — Sepal
ax = axes[0, 0]
for i, (sp, col) in enumerate(zip(species_list, colors)):
    mask = df['species'] == sp
    ax.scatter(df[mask]['sepal length (cm)'],
               df[mask]['sepal width (cm)'],
               c=col, label=sp, alpha=0.7, edgecolors='white', s=60)
ax.set_xlabel('Sepal Length (cm)')
ax.set_ylabel('Sepal Width (cm)')
ax.set_title('Sepal: Length vs Width')
ax.legend(fontsize=8)
ax.grid(True, alpha=0.3)

# Plot 2: Petal scatter
ax = axes[0, 1]
for i, (sp, col) in enumerate(zip(species_list, colors)):
    mask = df['species'] == sp
    ax.scatter(df[mask]['petal length (cm)'],
               df[mask]['petal width (cm)'],
               c=col, label=sp, alpha=0.7, edgecolors='white', s=60)
ax.set_xlabel('Petal Length (cm)')
ax.set_ylabel('Petal Width (cm)')
ax.set_title('Petal: Length vs Width')
ax.legend(fontsize=8)
ax.grid(True, alpha=0.3)

# Plot 3: Box plot — Petal Length by Species
ax = axes[0, 2]
data_bp = [df[df['species'] == sp]['petal length (cm)'].values for sp in species_list]
bp = ax.boxplot(data_bp, patch_artist=True, labels=species_list)
for patch, color in zip(bp['boxes'], colors):
    patch.set_facecolor(color)
    patch.set_alpha(0.7)
ax.set_ylabel('Petal Length (cm)')
ax.set_title('Petal Length Distribution by Species')
ax.grid(True, alpha=0.3)

# Plot 4: Feature correlation heatmap
ax = axes[1, 0]
corr = df.drop(columns=['target', 'species']).corr()
sns.heatmap(corr, annot=True, fmt='.2f', cmap='coolwarm',
            ax=ax, linewidths=0.5, square=True, cbar_kws={'shrink': 0.8})
ax.set_title('Feature Correlation Heatmap')

# Plot 5: Class distribution bar
ax = axes[1, 1]
counts = df['species'].value_counts()
bars = ax.bar(counts.index, counts.values, color=colors, alpha=0.8, edgecolor='white', linewidth=1.2)
for bar, count in zip(bars, counts.values):
    ax.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.5,
            str(count), ha='center', va='bottom', fontweight='bold')
ax.set_title('Class Distribution')
ax.set_ylabel('Count')
ax.grid(True, alpha=0.3, axis='y')

# Plot 6: Violin plot — Sepal Length
ax = axes[1, 2]
for i, (sp, col) in enumerate(zip(species_list, colors)):
    data_v = df[df['species'] == sp]['sepal length (cm)'].values
    parts = ax.violinplot(data_v, positions=[i], showmeans=True)
    for pc in parts['bodies']:
        pc.set_facecolor(col)
        pc.set_alpha(0.7)
ax.set_xticks(range(3))
ax.set_xticklabels(species_list, rotation=10)
ax.set_ylabel('Sepal Length (cm)')
ax.set_title('Sepal Length Distribution (Violin)')
ax.grid(True, alpha=0.3)

plt.tight_layout()
plt.savefig('/mnt/user-data/outputs/iris_eda.png', dpi=150, bbox_inches='tight')
plt.close()
print("\n✅ EDA plots saved!")

# ── 5. PREPROCESSING ─────────────────────────────────────────────
X = iris.data
y = iris.target

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42, stratify=y)

scaler = StandardScaler()
X_train_sc = scaler.fit_transform(X_train)
X_test_sc = scaler.transform(X_test)

print(f"\n🔀 Train/Test Split: {X_train.shape[0]} train | {X_test.shape[0]} test")

# ── 6. TRAIN MULTIPLE MODELS ─────────────────────────────────────
models = {
    'Logistic Regression': LogisticRegression(max_iter=200, random_state=42),
    'K-Nearest Neighbors': KNeighborsClassifier(n_neighbors=5),
    'Random Forest':       RandomForestClassifier(n_estimators=100, random_state=42),
    'Support Vector Machine': SVC(kernel='rbf', C=1.0, random_state=42)
}

results = {}
print("\n🤖 Training & Evaluating Models...")
print("-" * 55)

for name, model in models.items():
    model.fit(X_train_sc, y_train)
    y_pred = model.predict(X_test_sc)
    acc = accuracy_score(y_test, y_pred)
    cv_scores = cross_val_score(model, X_train_sc, y_train, cv=5)
    results[name] = {
        'model': model,
        'accuracy': acc,
        'cv_mean': cv_scores.mean(),
        'cv_std': cv_scores.std(),
        'y_pred': y_pred
    }
    print(f"  {name:<28} | Accuracy: {acc*100:.1f}% | CV: {cv_scores.mean()*100:.1f}% ± {cv_scores.std()*100:.1f}%")

# ── 7. BEST MODEL REPORT ─────────────────────────────────────────
best_name = max(results, key=lambda k: results[k]['accuracy'])
best = results[best_name]
print(f"\n🏆 Best Model: {best_name} ({best['accuracy']*100:.1f}%)")
print("\n📋 Classification Report (Best Model):")
print(classification_report(y_test, best['y_pred'],
                            target_names=iris.target_names))

# ── 8. CONFUSION MATRICES + ACCURACY BAR ────────────────────────
fig, axes = plt.subplots(2, 3, figsize=(16, 10))
fig.suptitle("Model Evaluation — Iris Flower Classification\n"
             "Mote Ishwar Sunil | Ishwar's Tech | CodeAlpha Internship",
             fontsize=13, fontweight='bold', color='#2c3e50')

model_colors = ['#3498db', '#e74c3c', '#2ecc71', '#9b59b6']

# Confusion matrices
for ax, (name, res), col in zip(axes.flat[:4], results.items(), model_colors):
    cm = confusion_matrix(y_test, res['y_pred'])
    disp = ConfusionMatrixDisplay(confusion_matrix=cm,
                                  display_labels=iris.target_names)
    disp.plot(ax=ax, colorbar=False, cmap='Blues')
    ax.set_title(f"{name}\nAccuracy: {res['accuracy']*100:.1f}%",
                 fontsize=10, fontweight='bold')
    ax.tick_params(axis='x', rotation=15)

# Accuracy comparison bar chart
ax = axes[1, 1]
names_short = ['Log. Reg.', 'KNN', 'Rnd. Forest', 'SVM']
accs = [res['accuracy']*100 for res in results.values()]
cv_means = [res['cv_mean']*100 for res in results.values()]
cv_stds = [res['cv_std']*100 for res in results.values()]

x = np.arange(len(names_short))
w = 0.35
bars1 = ax.bar(x - w/2, accs, w, label='Test Accuracy',
               color=model_colors, alpha=0.85, edgecolor='white')
bars2 = ax.bar(x + w/2, cv_means, w, label='CV Mean Accuracy',
               color=model_colors, alpha=0.45, edgecolor='white',
               yerr=cv_stds, capsize=4)
for bar, acc in zip(bars1, accs):
    ax.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.3,
            f'{acc:.1f}%', ha='center', va='bottom', fontsize=8, fontweight='bold')
ax.set_xticks(x)
ax.set_xticklabels(names_short, fontsize=9)
ax.set_ylabel('Accuracy (%)')
ax.set_ylim(85, 105)
ax.set_title('Model Accuracy Comparison')
ax.legend(fontsize=8)
ax.grid(True, alpha=0.3, axis='y')

# Feature importance (Random Forest)
ax = axes[1, 2]
rf_model = results['Random Forest']['model']
importances = rf_model.feature_importances_
feat_names = ['Sepal Len', 'Sepal Wid', 'Petal Len', 'Petal Wid']
sorted_idx = np.argsort(importances)
bars = ax.barh(np.array(feat_names)[sorted_idx],
               importances[sorted_idx],
               color='#2ecc71', alpha=0.8, edgecolor='white')
for bar, val in zip(bars, importances[sorted_idx]):
    ax.text(bar.get_width() + 0.005, bar.get_y() + bar.get_height()/2,
            f'{val:.3f}', va='center', fontsize=9, fontweight='bold')
ax.set_xlabel('Importance Score')
ax.set_title('Feature Importance\n(Random Forest)')
ax.grid(True, alpha=0.3, axis='x')

plt.tight_layout()
plt.savefig('/mnt/user-data/outputs/iris_model_evaluation.png', dpi=150, bbox_inches='tight')
plt.close()
print("✅ Model evaluation plots saved!")

# ── 9. PREDICTION DEMO ───────────────────────────────────────────
print("\n🌸 Live Prediction Demo (using best model):")
print("-" * 55)
samples = np.array([
    [5.1, 3.5, 1.4, 0.2],   # Setosa
    [6.7, 3.1, 4.7, 1.5],   # Versicolor
    [6.3, 3.3, 6.0, 2.5],   # Virginica
])
sample_names = ['Setosa (expected)', 'Versicolor (expected)', 'Virginica (expected)']
samples_sc = scaler.transform(samples)
predictions = best['model'].predict(samples_sc)
for s, pred, exp in zip(samples, predictions, sample_names):
    print(f"  Input: {s}  →  Predicted: {iris.target_names[pred]:<12}  [{exp}]")

print("\n" + "=" * 65)
print("  ✅ ALL TASKS COMPLETE — CodeAlpha Iris Classification")
print("  📁 Files saved:")
print("     /outputs/iris_eda.png")
print("     /outputs/iris_model_evaluation.png")
print("=" * 65)
